/**
 * @file course.c
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */



#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief To create a new course with a list of students enrolled 
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  //Allocate memory for the students,if the number of total students is 1, then allocate memory for the first student
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  // If the number of total students is greater than 1, then reallocate memory for the next student
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}
/**
 * @brief Print the students enrolled in a course and their total score
 * 
 * @param course 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
 * @brief Finding and returning the student who topped the course
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  //If there is no student in the course, return NULL
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 //Loop through the students to find the highest average
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    //If the current student average is higher than the max average, then update the max average and the student
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }
  return student;
}
/**
 * @brief Finding and returning the array of students who passed the course
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  //Find the number of students who passed and allocating memory for the array of students who passed
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  //Copy the students who passed to the array "passing"
  for (int i = 0; i < course->total_students; i++)
  {
    //If the student has an average of more than or equal to 50, copy the student to the array "passing"
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}