var searchData=
[
  ['student_0',['Student',['../student_8h.html#ac91ec92866bb82e1ee36c75280929c43',1,'student.h']]],
  ['student_2ec_1',['student.c',['../student_8c.html',1,'']]],
  ['student_2eh_2',['student.h',['../student_8h.html',1,'']]]
];
